"use client";

import { Product } from '@/contexts/CartContext';
import { useCart } from '@/contexts/CartContext';

interface ProductCardProps {
  product: Product;
  className?: string;
}

export default function ProductCard({ product, className = "" }: ProductCardProps) {
  const { dispatch } = useCart();

  const handleAddToCart = () => {
    dispatch({ type: 'ADD_ITEM', payload: product });
  };

  return (
    <div className={`group cursor-pointer ${className}`}>
      <div className="relative overflow-hidden rounded-lg bg-black border border-gold/20 hover:border-gold/50 transition-all duration-300">
        <img 
          src={product.image}
          alt={`${product.name} - Parfum original de luxe`}
          className="w-full h-80 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        
        {/* Stock Status */}
        {!product.inStock && (
          <div className="absolute top-4 left-4 bg-red-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
            Rupture de stock
          </div>
        )}
        
        {/* Product Info Overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-6 text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
          <h3 className="font-playfair text-xl font-bold mb-2">{product.name}</h3>
          <p className="text-gold text-lg font-semibold mb-2">{product.price}</p>
          {product.description && (
            <p className="text-gray-300 text-sm mb-3 line-clamp-2">{product.description}</p>
          )}
          <button 
            onClick={handleAddToCart}
            disabled={!product.inStock}
            className={`w-full font-semibold py-2 px-4 rounded transition-colors duration-300 ${
              product.inStock 
                ? 'bg-gold hover:bg-yellow-500 text-black' 
                : 'bg-gray-600 text-gray-400 cursor-not-allowed'
            }`}
          >
            {product.inStock ? 'Ajouter au panier' : 'Indisponible'}
          </button>
        </div>
      </div>
      
      {/* Product Info Below */}
      <div className="pt-4 text-center">
        <h3 className="font-playfair text-lg font-semibold text-white mb-1">{product.name}</h3>
        <p className="text-gray-400 text-sm mb-2">{product.category}</p>
        <p className="text-gold text-xl font-bold">{product.price}</p>
        {!product.inStock && (
          <p className="text-red-400 text-sm mt-1">Rupture de stock</p>
        )}
      </div>
    </div>
  );
}