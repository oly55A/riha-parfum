import { Product } from '@/contexts/CartContext';

export const products: Product[] = [
  // Versace Collection
  {
    id: 1,
    name: "Versace Eros",
    price: "950 dh",
    priceValue: 950,
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/2e0ac7d0-d623-4014-a50a-89d3127da4c9.png",
    category: "Versace",
    description: "Un parfum masculin puissant et séduisant avec des notes de menthe, pomme verte et vanille.",
    inStock: true
  },
  {
    id: 2,
    name: "Versace Bright Crystal",
    price: "890 dh",
    priceValue: 890,
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/8a3b906c-d8ac-4c25-8ca6-60bc80b258c0.png",
    category: "Versace",
    description: "Un parfum féminin lumineux avec des notes de yuzu, pivoine et bois d'acajou.",
    inStock: true
  },
  {
    id: 3,
    name: "Versace Dylan Blue",
    price: "920 dh",
    priceValue: 920,
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/d1bb47de-744e-4be7-95e1-eb3f7b7112b2.png",
    category: "Versace",
    description: "Un parfum moderne et sophistiqué avec des notes d'agrumes, violette et patchouli.",
    inStock: true
  },

  // Gucci Collection
  {
    id: 4,
    name: "Gucci Bloom",
    price: "890 dh",
    priceValue: 890,
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/86381a8f-45c2-4d7f-9055-a7b9037fa954.png",
    category: "Gucci",
    description: "Un parfum floral authentique avec des notes de jasmin, tubéreuse et Rangoon.",
    inStock: true
  },
  {
    id: 5,
    name: "Gucci Guilty",
    price: "850 dh",
    priceValue: 850,
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/43da7560-81ad-4b45-a99f-0d67ef932ba1.png",
    category: "Gucci",
    description: "Un parfum audacieux et provocant avec des notes de mandarine, géranium et patchouli.",
    inStock: true
  },
  {
    id: 6,
    name: "Gucci Flora",
    price: "870 dh",
    priceValue: 870,
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/6b2d502c-2e61-4cd4-8c3c-fe8ef68d0abe.png",
    category: "Gucci",
    description: "Un parfum féminin et délicat avec des notes de pivoine, rose et osmanthus.",
    inStock: true
  },

  // Tom Ford Collection
  {
    id: 7,
    name: "Tom Ford Black Orchid",
    price: "1200 dh",
    priceValue: 1200,
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/344572f7-38ff-46a1-922b-e5deb7f66f5c.png",
    category: "Tom Ford",
    description: "Un parfum luxueux et mystérieux avec des notes d'orchidée noire, truffe et ylang-ylang.",
    inStock: true
  },
  {
    id: 8,
    name: "Tom Ford Oud Wood",
    price: "1350 dh",
    priceValue: 1350,
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/defa8b12-d125-4880-9148-21131484f6c5.png",
    category: "Tom Ford",
    description: "Un parfum oriental sophistiqué avec des notes de bois d'oud, palissandre et santal.",
    inStock: true
  },

  // Chanel Collection
  {
    id: 9,
    name: "Chanel No. 5",
    price: "1100 dh",
    priceValue: 1100,
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/07004011-4bcb-4100-9f9f-964ef993c7fd.png",
    category: "Chanel",
    description: "Le parfum iconique avec des notes d'aldéhydes, ylang-ylang et santal.",
    inStock: true
  },
  {
    id: 10,
    name: "Chanel Coco Mademoiselle",
    price: "1050 dh",
    priceValue: 1050,
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/f9fb19d5-c5bf-440d-a404-ff14583ef808.png",
    category: "Chanel",
    description: "Un parfum moderne et élégant avec des notes d'orange, jasmin et patchouli.",
    inStock: true
  },
  {
    id: 11,
    name: "Chanel Chance",
    price: "980 dh",
    priceValue: 980,
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/5e1e4b2e-f39d-42d6-87d6-b69be297e56f.png",
    category: "Chanel",
    description: "Un parfum pétillant et imprévisible avec des notes de pamplemousse, jasmin et ambre blanc.",
    inStock: true
  },

  // Dior Collection
  {
    id: 12,
    name: "Dior Sauvage",
    price: "1000 dh",
    priceValue: 1000,
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/c62a39ae-df30-443e-918d-72bba795dc62.png",
    category: "Dior",
    description: "Un parfum masculin sauvage avec des notes de bergamote, poivre et ambroxan.",
    inStock: true
  },
  {
    id: 13,
    name: "Dior J'adore",
    price: "950 dh",
    priceValue: 950,
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/4f24e9be-1956-4ad1-9807-eddd68fc6f02.png",
    category: "Dior",
    description: "Un parfum féminin lumineux avec des notes d'ylang-ylang, rose de Damas et jasmin.",
    inStock: true
  },

  // Yves Saint Laurent Collection
  {
    id: 14,
    name: "YSL Black Opium",
    price: "920 dh",
    priceValue: 920,
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/e52a0ea1-d79b-40bf-b4af-f5cfbf2f9e53.png",
    category: "YSL",
    description: "Un parfum addictif et mystérieux avec des notes de café noir, vanille et fleur d'oranger.",
    inStock: true
  },
  {
    id: 15,
    name: "YSL Libre",
    price: "890 dh",
    priceValue: 890,
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/27b2cb40-7834-431b-b421-3c117a96574d.png",
    category: "YSL",
    description: "Un parfum de liberté avec des notes de lavande, fleur d'oranger et vanille.",
    inStock: true
  }
];

export const categories = [
  {
    name: "Versace",
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/3f2b5c14-67d9-4f7b-8e07-72a49f3c2e37.png",
    count: products.filter(p => p.category === "Versace").length,
    description: "Collection de parfums italiens luxueux et audacieux"
  },
  {
    name: "Gucci",
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/1aec3004-8855-4062-9a90-cba0f74d82e3.png",
    count: products.filter(p => p.category === "Gucci").length,
    description: "Parfums sophistiqués et élégants de la maison italienne"
  },
  {
    name: "Tom Ford",
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/c70bb35f-3b97-462d-b686-e2d0792912bd.png",
    count: products.filter(p => p.category === "Tom Ford").length,
    description: "Fragrances de luxe américaines, raffinées et exclusives"
  },
  {
    name: "Chanel",
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/71409b27-d66a-4805-ac35-e1e611da994d.png",
    count: products.filter(p => p.category === "Chanel").length,
    description: "Parfums iconiques français, symboles d'élégance intemporelle"
  },
  {
    name: "Dior",
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/3920e2f4-7739-40f6-9cac-f7b2bf1f6592.png",
    count: products.filter(p => p.category === "Dior").length,
    description: "Fragrances françaises de prestige, alliant tradition et modernité"
  },
  {
    name: "YSL",
    image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/9b65f4a9-d45a-4ca5-8ea7-6aa016c1d309.png",
    count: products.filter(p => p.category === "YSL").length,
    description: "Parfums audacieux et avant-gardistes de la maison de couture"
  }
];

export const getProductById = (id: number): Product | undefined => {
  return products.find(product => product.id === id);
};

export const getProductsByCategory = (category: string): Product[] => {
  return products.filter(product => product.category === category);
};

export const getFeaturedProducts = (): Product[] => {
  return products.slice(0, 8);
};

export const searchProducts = (query: string): Product[] => {
  const lowercaseQuery = query.toLowerCase();
  return products.filter(product => 
    product.name.toLowerCase().includes(lowercaseQuery) ||
    product.category.toLowerCase().includes(lowercaseQuery) ||
    product.description?.toLowerCase().includes(lowercaseQuery)
  );
};