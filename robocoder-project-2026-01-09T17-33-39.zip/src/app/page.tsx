"use client";

export default function HomePage() {

  const featuredProducts = [
    {
      id: 1,
      name: "Versace Eros",
      price: "950 dh",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/1f9e39e4-fa8c-4c79-8086-94e3529a389c.png",
      category: "Versace"
    },
    {
      id: 2,
      name: "Gucci Bloom",
      price: "890 dh",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/8eac77a1-75f1-4100-a9b1-d6875e177159.png",
      category: "Gucci"
    },
    {
      id: 3,
      name: "Tom Ford Black Orchid",
      price: "1200 dh",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/43ff553f-5c0c-4aef-a9c1-257e5bbc7403.png",
      category: "Tom Ford"
    },
    {
      id: 4,
      name: "Chanel No. 5",
      price: "1100 dh",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/21e8eb89-ef3a-4902-a456-05dc85a3d6d1.png",
      category: "Chanel"
    }
  ];

  const categories = [
    {
      name: "Versace",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/f30ade73-0f37-4703-827d-743f54c17c3b.png",
      count: "12 parfums"
    },
    {
      name: "Gucci",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/913dc783-4a3e-481a-89d4-d2c164da205e.png",
      count: "8 parfums"
    },
    {
      name: "Tom Ford",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/a2f48a34-60b2-4644-94ce-4baffe7201e1.png",
      count: "6 parfums"
    },
    {
      name: "Chanel",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/0740e147-983f-402a-a106-2bebfaeaef50.png",
      count: "10 parfums"
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        {/* Background Video Placeholder */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/f424bb17-01ce-4ae1-ada3-bcb07fb661bd.png" 
            alt="Luxury perfume showcase video background"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/60"></div>
        </div>

        {/* Hero Content */}
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <div className="mb-8">
            <img 
              src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/83c3cf7d-2077-4254-8b79-ba1e5b9ea424.png" 
              alt="RIHA PARFUMERIE - Elegant logo with square border and circular emblem"
              className="mx-auto mb-6 rounded-lg border-2 border-gold/50"
            />
          </div>
          
          <h1 className="font-playfair text-5xl md:text-7xl font-bold text-white mb-4">
            RIHA PARFUMERIE
          </h1>
          
          <p className="text-xl md:text-2xl text-gold mb-2 font-light">
            Vente de parfums originaux à 100%
          </p>
          
          <p className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">
            Découvrez notre collection exclusive de parfums de luxe. Authenticité garantie, livraison rapide à Casablanca et partout au Maroc.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-gold hover:bg-yellow-500 text-black font-semibold py-4 px-8 rounded-lg transition-all duration-300 transform hover:scale-105">
              Découvrir nos parfums
            </button>
            <button className="border-2 border-gold text-gold hover:bg-gold hover:text-black font-semibold py-4 px-8 rounded-lg transition-all duration-300">
              Voir les marques
            </button>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-gold animate-bounce">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="py-20 bg-gray-900">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-playfair text-4xl md:text-5xl font-bold text-white mb-4">
              Parfums Vedettes
            </h2>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Découvrez notre sélection de parfums les plus populaires, choisis avec soin pour leur qualité exceptionnelle.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredProducts.map((product) => (
              <div key={product.id} className="group cursor-pointer">
                <div className="relative overflow-hidden rounded-lg bg-black border border-gold/20 hover:border-gold/50 transition-all duration-300">
                  <img 
                    src={product.image}
                    alt={`${product.name} - Parfum original de luxe`}
                    className="w-full h-80 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  
                  {/* Product Info Overlay */}
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                    <h3 className="font-playfair text-xl font-bold mb-2">{product.name}</h3>
                    <p className="text-gold text-lg font-semibold mb-3">{product.price}</p>
                    <button className="w-full bg-gold hover:bg-yellow-500 text-black font-semibold py-2 px-4 rounded transition-colors duration-300">
                      Ajouter au panier
                    </button>
                  </div>
                </div>
                
                {/* Product Info Below */}
                <div className="pt-4 text-center">
                  <h3 className="font-playfair text-lg font-semibold text-white mb-1">{product.name}</h3>
                  <p className="text-gray-400 text-sm mb-2">{product.category}</p>
                  <p className="text-gold text-xl font-bold">{product.price}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <button className="bg-transparent border-2 border-gold text-gold hover:bg-gold hover:text-black font-semibold py-3 px-8 rounded-lg transition-all duration-300">
              Voir tous les produits
            </button>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-playfair text-4xl md:text-5xl font-bold text-white mb-4">
              Nos Marques de Luxe
            </h2>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Explorez notre collection exclusive des plus grandes marques de parfumerie mondiale.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {categories.map((category, index) => (
              <div key={index} className="group cursor-pointer">
                <div className="relative overflow-hidden rounded-lg border-2 border-gold/30 hover:border-gold transition-all duration-300">
                  <img 
                    src={category.image}
                    alt={`Collection ${category.name} - Parfums de luxe authentiques`}
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent"></div>
                  
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                    <h3 className="font-playfair text-2xl font-bold mb-2 text-gold">{category.name}</h3>
                    <p className="text-gray-300">{category.count}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Preview Section */}
      <section className="py-20 bg-gray-900">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="font-playfair text-4xl md:text-5xl font-bold text-white mb-8">
              Pourquoi Choisir RIHA PARFUMERIE ?
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
              <div className="text-center">
                <div className="w-16 h-16 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl text-gold">✓</span>
                </div>
                <h3 className="font-playfair text-xl font-semibold text-white mb-3">100% Authentique</h3>
                <p className="text-gray-300">Tous nos parfums sont garantis authentiques et originaux.</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl text-gold">🚚</span>
                </div>
                <h3 className="font-playfair text-xl font-semibold text-white mb-3">Livraison Rapide</h3>
                <p className="text-gray-300">Livraison à Casa 0-30 dh, hors Casa 30-50 dh.</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl text-gold">📍</span>
                </div>
                <h3 className="font-playfair text-xl font-semibold text-white mb-3">Basé à Casablanca</h3>
                <p className="text-gray-300">Service local de confiance au cœur du Maroc.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-gold/10 to-copper/10">
        <div className="container mx-auto px-4 text-center">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-white mb-6">
            Prêt à Découvrir Votre Parfum Idéal ?
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Rejoignez des milliers de clients satisfaits qui font confiance à RIHA PARFUMERIE pour leurs parfums de luxe.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-gold hover:bg-yellow-500 text-black font-semibold py-4 px-8 rounded-lg transition-all duration-300 transform hover:scale-105">
              Explorer la Collection
            </button>
            <button className="border-2 border-white text-white hover:bg-white hover:text-black font-semibold py-4 px-8 rounded-lg transition-all duration-300">
              Nous Contacter
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}