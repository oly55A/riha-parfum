"use client";

import { useState } from 'react';

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission here
    console.log('Form submitted:', formData);
    // Reset form
    setFormData({
      name: '',
      email: '',
      phone: '',
      subject: '',
      message: ''
    });
    alert('Merci pour votre message ! Nous vous répondrons dans les plus brefs délais.');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-black via-gray-900 to-black">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-playfair text-5xl md:text-6xl font-bold text-white mb-6">
            Contactez-Nous
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Notre équipe est à votre disposition pour répondre à toutes vos questions
          </p>
        </div>
      </section>

      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="bg-gray-900 rounded-lg p-8 border border-gold/20">
            <h2 className="font-playfair text-3xl font-bold text-white mb-8">
              Envoyez-nous un message
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-gold font-semibold mb-2">
                    Nom complet *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full bg-black border border-gold/30 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-gold focus:outline-none"
                    placeholder="Votre nom complet"
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-gold font-semibold mb-2">
                    Email *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full bg-black border border-gold/30 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-gold focus:outline-none"
                    placeholder="votre@email.com"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="phone" className="block text-gold font-semibold mb-2">
                  Téléphone
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full bg-black border border-gold/30 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-gold focus:outline-none"
                  placeholder="+212 6XX XXX XXX"
                />
              </div>

              <div>
                <label htmlFor="subject" className="block text-gold font-semibold mb-2">
                  Sujet *
                </label>
                <select
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                  className="w-full bg-black border border-gold/30 rounded-lg px-4 py-3 text-white focus:border-gold focus:outline-none"
                >
                  <option value="">Sélectionnez un sujet</option>
                  <option value="product-inquiry">Demande de renseignements produit</option>
                  <option value="order-status">Statut de commande</option>
                  <option value="delivery">Questions de livraison</option>
                  <option value="authenticity">Authenticité des produits</option>
                  <option value="partnership">Partenariat</option>
                  <option value="other">Autre</option>
                </select>
              </div>

              <div>
                <label htmlFor="message" className="block text-gold font-semibold mb-2">
                  Message *
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={6}
                  className="w-full bg-black border border-gold/30 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-gold focus:outline-none resize-vertical"
                  placeholder="Décrivez votre demande en détail..."
                />
              </div>

              <button
                type="submit"
                className="w-full bg-gold hover:bg-yellow-500 text-black font-semibold py-4 px-6 rounded-lg transition-colors duration-300"
              >
                Envoyer le message
              </button>
            </form>
          </div>

          {/* Contact Information */}
          <div className="space-y-8">
            {/* Contact Details */}
            <div className="bg-gray-900 rounded-lg p-8 border border-gold/20">
              <h3 className="font-playfair text-2xl font-bold text-white mb-6">
                Informations de Contact
              </h3>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gold/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-gold text-xl">📍</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-1">Adresse</h4>
                    <p className="text-gray-300">Casablanca, Maroc</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gold/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-gold text-xl">📱</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-1">Instagram</h4>
                    <a 
                      href="https://instagram.com/riha_parfumerie" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-gold hover:text-yellow-400 transition-colors"
                    >
                      @riha_parfumerie
                    </a>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gold/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-gold text-xl">🕒</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-1">Horaires</h4>
                    <p className="text-gray-300">Lun - Sam: 9h00 - 20h00</p>
                    <p className="text-gray-300">Dimanche: 10h00 - 18h00</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Delivery Information */}
            <div className="bg-gray-900 rounded-lg p-8 border border-gold/20">
              <h3 className="font-playfair text-2xl font-bold text-white mb-6">
                Livraison
              </h3>
              
              <div className="space-y-4">
                <div className="flex justify-between items-center py-2 border-b border-gold/20">
                  <span className="text-gray-300">Casablanca</span>
                  <span className="text-gold font-semibold">0-30 dh</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-gold/20">
                  <span className="text-gray-300">Hors Casablanca</span>
                  <span className="text-gold font-semibold">30-50 dh</span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-300">Délai de livraison</span>
                  <span className="text-gold font-semibold">24-72h</span>
                </div>
              </div>
            </div>

            {/* FAQ Quick Links */}
            <div className="bg-gray-900 rounded-lg p-8 border border-gold/20">
              <h3 className="font-playfair text-2xl font-bold text-white mb-6">
                Questions Fréquentes
              </h3>
              
              <div className="space-y-3">
                <div className="text-gray-300">
                  <h4 className="font-semibold text-white mb-1">Vos parfums sont-ils authentiques ?</h4>
                  <p className="text-sm">Oui, tous nos parfums sont 100% authentiques et importés directement des marques officielles.</p>
                </div>
                
                <div className="text-gray-300">
                  <h4 className="font-semibold text-white mb-1">Puis-je retourner un produit ?</h4>
                  <p className="text-sm">Oui, nous acceptons les retours dans les 7 jours suivant la livraison, produit non ouvert.</p>
                </div>
                
                <div className="text-gray-300">
                  <h4 className="font-semibold text-white mb-1">Comment suivre ma commande ?</h4>
                  <p className="text-sm">Vous recevrez un numéro de suivi par message après l'expédition de votre commande.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}