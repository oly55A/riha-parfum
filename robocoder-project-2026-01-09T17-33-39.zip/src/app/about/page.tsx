export default function AboutPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-black via-gray-900 to-black">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-playfair text-5xl md:text-6xl font-bold text-white mb-6">
            À Propos de RIHA PARFUMERIE
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Votre destination de confiance pour les parfums de luxe authentiques au Maroc
          </p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="font-playfair text-4xl font-bold text-white mb-6">
                  Notre Histoire
                </h2>
                <p className="text-gray-300 mb-6 leading-relaxed">
                  RIHA PARFUMERIE est née de la passion pour les fragrances exceptionnelles et de l'engagement 
                  à offrir aux amateurs de parfums marocains l'accès aux plus grandes marques de luxe mondiales.
                </p>
                <p className="text-gray-300 mb-6 leading-relaxed">
                  Basée à Casablanca, notre boutique s'est rapidement imposée comme une référence dans le domaine 
                  de la parfumerie de luxe, grâce à notre sélection rigoureuse et notre service client exceptionnel.
                </p>
                <p className="text-gray-300 leading-relaxed">
                  Chaque parfum de notre collection est soigneusement choisi pour sa qualité, son authenticité 
                  et son caractère unique, garantissant à nos clients une expérience olfactive inoubliable.
                </p>
              </div>
              <div className="relative">
                <img 
                  src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/0d05ebd2-3a24-448b-afd5-28f5089db51d.png" 
                  alt="RIHA PARFUMERIE - Intérieur élégant de la boutique avec présentoirs de luxe"
                  className="w-full h-96 object-cover rounded-lg border border-gold/30"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-20 bg-gray-900">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-playfair text-4xl font-bold text-white mb-6">
              Nos Valeurs
            </h2>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Les principes qui guident notre engagement envers l'excellence
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-3xl text-gold">✓</span>
              </div>
              <h3 className="font-playfair text-2xl font-semibold text-white mb-4">
                Authenticité Garantie
              </h3>
              <p className="text-gray-300 leading-relaxed">
                Tous nos parfums sont 100% authentiques, importés directement des marques officielles. 
                Nous garantissons l'origine et la qualité de chaque produit.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-3xl text-gold">🎯</span>
              </div>
              <h3 className="font-playfair text-2xl font-semibold text-white mb-4">
                Excellence du Service
              </h3>
              <p className="text-gray-300 leading-relaxed">
                Notre équipe d'experts vous accompagne dans le choix de votre parfum idéal, 
                avec des conseils personnalisés et un service client irréprochable.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-3xl text-gold">💎</span>
              </div>
              <h3 className="font-playfair text-2xl font-semibold text-white mb-4">
                Sélection Premium
              </h3>
              <p className="text-gray-300 leading-relaxed">
                Nous sélectionnons uniquement les fragrances les plus raffinées des maisons 
                de parfumerie les plus prestigieuses au monde.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Location & Delivery */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Location */}
              <div className="bg-gray-900 rounded-lg p-8 border border-gold/20">
                <h3 className="font-playfair text-3xl font-bold text-white mb-6">
                  Notre Localisation
                </h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <span className="text-gold text-xl">📍</span>
                    <div>
                      <h4 className="font-semibold text-white mb-1">Adresse</h4>
                      <p className="text-gray-300">Casablanca, Maroc</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-gold text-xl">🕒</span>
                    <div>
                      <h4 className="font-semibold text-white mb-1">Horaires</h4>
                      <p className="text-gray-300">Lun - Sam: 9h00 - 20h00</p>
                      <p className="text-gray-300">Dimanche: 10h00 - 18h00</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-gold text-xl">📱</span>
                    <div>
                      <h4 className="font-semibold text-white mb-1">Contact</h4>
                      <p className="text-gray-300">Instagram: @riha_parfumerie</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Delivery */}
              <div className="bg-gray-900 rounded-lg p-8 border border-gold/20">
                <h3 className="font-playfair text-3xl font-bold text-white mb-6">
                  Livraison
                </h3>
                <div className="space-y-6">
                  <div className="flex items-start space-x-3">
                    <span className="text-gold text-xl">🚚</span>
                    <div>
                      <h4 className="font-semibold text-white mb-2">Casablanca</h4>
                      <p className="text-gray-300 mb-1">Livraison: 0-30 dh</p>
                      <p className="text-gray-300">Délai: 24h</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-gold text-xl">📦</span>
                    <div>
                      <h4 className="font-semibold text-white mb-2">Hors Casablanca</h4>
                      <p className="text-gray-300 mb-1">Livraison: 30-50 dh</p>
                      <p className="text-gray-300">Délai: 48-72h</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-gold text-xl">✅</span>
                    <div>
                      <h4 className="font-semibold text-white mb-2">Garanties</h4>
                      <p className="text-gray-300 mb-1">Emballage sécurisé</p>
                      <p className="text-gray-300 mb-1">Suivi de commande</p>
                      <p className="text-gray-300">Satisfaction garantie</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Brands We Carry */}
      <section className="py-20 bg-gray-900">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-playfair text-4xl font-bold text-white mb-6">
              Nos Marques Partenaires
            </h2>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Nous travaillons exclusivement avec les plus prestigieuses maisons de parfumerie
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
            {['Versace', 'Gucci', 'Tom Ford', 'Chanel', 'Dior', 'YSL'].map((brand) => (
              <div key={brand} className="text-center">
                <div className="w-20 h-20 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-gold/30">
                  <span className="font-playfair text-gold font-bold text-sm">{brand}</span>
                </div>
                <p className="text-gray-300 font-semibold">{brand}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-gold/10 to-copper/10">
        <div className="container mx-auto px-4 text-center">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-white mb-6">
            Rejoignez Notre Communauté
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Suivez-nous sur Instagram pour découvrir nos dernières nouveautés et bénéficier d'offres exclusives.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="https://instagram.com/riha_parfumerie" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-gold hover:bg-yellow-500 text-black font-semibold py-4 px-8 rounded-lg transition-all duration-300 transform hover:scale-105"
            >
              Suivre sur Instagram
            </a>
            <a 
              href="/contact"
              className="border-2 border-white text-white hover:bg-white hover:text-black font-semibold py-4 px-8 rounded-lg transition-all duration-300"
            >
              Nous Contacter
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}