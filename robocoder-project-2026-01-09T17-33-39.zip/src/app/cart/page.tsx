"use client";

import { useCart } from '@/contexts/CartContext';
import Link from 'next/link';

export default function CartPage() {
  const { state, dispatch } = useCart();

  const updateQuantity = (id: number, quantity: number) => {
    dispatch({ type: 'UPDATE_QUANTITY', payload: { id, quantity } });
  };

  const removeItem = (id: number) => {
    dispatch({ type: 'REMOVE_ITEM', payload: id });
  };

  const clearCart = () => {
    dispatch({ type: 'CLEAR_CART' });
  };

  if (state.items.length === 0) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-24 h-24 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg className="w-12 h-12 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-1.5 6M7 13l-1.5 6m0 0h9m-9 0V19a2 2 0 002 2h7a2 2 0 002-2v-4" />
            </svg>
          </div>
          <h2 className="font-playfair text-3xl font-bold text-white mb-4">
            Votre panier est vide
          </h2>
          <p className="text-gray-400 mb-8">
            Découvrez notre collection de parfums de luxe et ajoutez vos favoris au panier.
          </p>
          <Link 
            href="/products"
            className="bg-gold hover:bg-yellow-500 text-black font-semibold py-3 px-8 rounded-lg transition-colors duration-300"
          >
            Découvrir nos parfums
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <section className="py-12 bg-gray-900">
        <div className="container mx-auto px-4">
          <h1 className="font-playfair text-4xl md:text-5xl font-bold text-white mb-4">
            Votre Panier
          </h1>
          <p className="text-gray-300">
            {state.itemCount} article{state.itemCount > 1 ? 's' : ''} dans votre panier
          </p>
        </div>
      </section>

      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <div className="space-y-6">
              {state.items.map((item) => (
                <div key={item.id} className="bg-gray-900 rounded-lg p-6 border border-gold/20">
                  <div className="flex flex-col md:flex-row gap-6">
                    {/* Product Image */}
                    <div className="w-full md:w-32 h-40 md:h-32 flex-shrink-0">
                      <img 
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover rounded-lg"
                      />
                    </div>

                    {/* Product Info */}
                    <div className="flex-1">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="font-playfair text-xl font-semibold text-white">
                            {item.name}
                          </h3>
                          <p className="text-gray-400">{item.category}</p>
                        </div>
                        <button
                          onClick={() => removeItem(item.id)}
                          className="text-red-400 hover:text-red-300 transition-colors"
                        >
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      </div>

                      <div className="flex items-center justify-between">
                        {/* Quantity Controls */}
                        <div className="flex items-center space-x-3">
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="w-8 h-8 bg-gold/20 hover:bg-gold/30 rounded-full flex items-center justify-center text-gold transition-colors"
                          >
                            -
                          </button>
                          <span className="text-white font-semibold w-8 text-center">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="w-8 h-8 bg-gold/20 hover:bg-gold/30 rounded-full flex items-center justify-center text-gold transition-colors"
                          >
                            +
                          </button>
                        </div>

                        {/* Price */}
                        <div className="text-right">
                          <p className="text-gold font-bold text-lg">
                            {item.priceValue * item.quantity} dh
                          </p>
                          <p className="text-gray-400 text-sm">
                            {item.price} × {item.quantity}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Clear Cart Button */}
            <div className="mt-8">
              <button
                onClick={clearCart}
                className="text-red-400 hover:text-red-300 transition-colors font-semibold"
              >
                Vider le panier
              </button>
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-gray-900 rounded-lg p-6 border border-gold/20 sticky top-24">
              <h3 className="font-playfair text-2xl font-bold text-white mb-6">
                Résumé de la commande
              </h3>

              <div className="space-y-4 mb-6">
                <div className="flex justify-between">
                  <span className="text-gray-300">Sous-total</span>
                  <span className="text-white">{state.total} dh</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Livraison</span>
                  <span className="text-white">30 dh</span>
                </div>
                <div className="border-t border-gold/20 pt-4">
                  <div className="flex justify-between">
                    <span className="font-semibold text-white">Total</span>
                    <span className="font-bold text-gold text-xl">{state.total + 30} dh</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <button className="w-full bg-gold hover:bg-yellow-500 text-black font-semibold py-3 px-6 rounded-lg transition-colors duration-300">
                  Procéder au paiement
                </button>
                <Link 
                  href="/products"
                  className="w-full bg-transparent border border-gold text-gold hover:bg-gold hover:text-black font-semibold py-3 px-6 rounded-lg transition-colors duration-300 text-center block"
                >
                  Continuer les achats
                </Link>
              </div>

              {/* Delivery Info */}
              <div className="mt-6 p-4 bg-black/50 rounded-lg">
                <h4 className="font-semibold text-gold mb-2">Informations de livraison</h4>
                <ul className="text-sm text-gray-300 space-y-1">
                  <li>🚚 Livraison à Casa: 0-30 dh</li>
                  <li>🚚 Livraison hors Casa: 30-50 dh</li>
                  <li>📦 Livraison sous 24-48h</li>
                  <li>✅ Parfums 100% authentiques</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}